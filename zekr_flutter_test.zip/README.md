# ذِكر - Flutter Test App

نسخة تجريبية لتطبيق أذكار وتذكير بذكر الله.

## بناء APK من GitHub

1. ارفع المشروع إلى Repository جديد على GitHub.
2. اسمح لـ GitHub Actions بالعمل.
3. افتح تبويب Actions.
4. اختر Build Android APK.
5. اضغط Run workflow إذا لم يبدأ تلقائياً.
6. بعد انتهاء البناء افتح الـ workflow ثم Artifacts.
7. حمّل `zekr-release-apk` وفك الضغط عن الملف للحصول على APK.

## ملاحظات

هذه النسخة هي Prototype أولي. مراقبة وقت استخدام تطبيقات مثل Facebook/TikTok تحتاج إضافة Android Usage Access وKotlin Native في المرحلة التالية.
