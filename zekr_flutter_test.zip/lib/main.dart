import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;

final notifications = FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tz.initializeTimeZones();

  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  const settings = InitializationSettings(android: android);

  await notifications.initialize(settings);

  runApp(const ZekrApp());
}

class ZekrApp extends StatelessWidget {
  const ZekrApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ذِكر',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D1117),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF36C98F),
          brightness: Brightness.dark,
        ),
        fontFamily: 'sans',
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final zikr = 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ';
  int count = 0;

  Future<void> sendTestNotification() async {
    const details = AndroidNotificationDetails(
      'zekr_channel',
      'تذكيرات الذكر',
      channelDescription: 'تذكيرات قصيرة بذكر الله',
      importance: Importance.high,
      priority: Priority.high,
    );

    await notifications.show(
      1,
      'تذكير بسيط يا عمر',
      'خد 20 ثانية لذكر الله ❤️',
      const NotificationDetails(android: details),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('ذِكر'),
          centerTitle: true,
          backgroundColor: Colors.transparent,
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 20),
                const Text(
                  'تذكيرك اليومي',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  'مش لازم تقرأ كتير… دقيقة بسيطة ممكن تغيّر يومك.',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white.withValues(alpha: .65),
                  ),
                ),
                const SizedBox(height: 30),
                Card(
                  elevation: 0,
                  color: const Color(0xFF151C24),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      children: [
                        const Text(
                          'ذكر اليوم',
                          style: TextStyle(
                            fontSize: 16,
                            color: Color(0xFF36C98F),
                          ),
                        ),
                        const SizedBox(height: 24),
                        Text(
                          zikr,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 25,
                            height: 1.8,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 25),
                        Text(
                          'قرأته $count مرة',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: .55),
                          ),
                        ),
                        const SizedBox(height: 18),
                        FilledButton(
                          onPressed: () => setState(() => count++),
                          style: FilledButton.styleFrom(
                            minimumSize: const Size.fromHeight(52),
                          ),
                          child: const Text('قرأت الذكر'),
                        ),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
                OutlinedButton.icon(
                  onPressed: sendTestNotification,
                  icon: const Icon(Icons.notifications_active_outlined),
                  label: const Text('تجربة إشعار'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size.fromHeight(52),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'نسخة تجريبية 1.0',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: .35),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
